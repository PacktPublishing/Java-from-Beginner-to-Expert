package variables;

public class Variables {

    public static void main(String[] args) {
        String nameAndSurname = "Arkadiusz Włodarczyk";
        
        final double NUMBER_PI = 3.14;
        
     
                
        
        
        System.out.println(nameAndSurname);
    }
    
}
