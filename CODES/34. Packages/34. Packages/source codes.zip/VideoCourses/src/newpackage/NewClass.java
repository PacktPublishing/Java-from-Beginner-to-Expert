package newpackage;

import videocourses.Test;

public class NewClass {
    public static void main(String[] args) {

    }
}
