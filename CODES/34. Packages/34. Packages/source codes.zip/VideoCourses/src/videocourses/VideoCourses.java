package videocourses;

public class VideoCourses {
    
    public static void main(String[] args) {

    }
    
}

