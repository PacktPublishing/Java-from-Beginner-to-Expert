
package basics;

public class Basics {
    
    public static void main(String[] args) {
        
        System.out.print("SAMPLE TEXT");
      
    }
    
}
