
package casting;

public class Casting {

    public static void main(String[] args) {
        int a = (int)5.4, b = 2;
        double c = 12, d = 15;
        
        
        int result = a / (int)d;
        double result2 = c / a;
        
        System.out.println(1.0 / 5);
        
    }
    
}
