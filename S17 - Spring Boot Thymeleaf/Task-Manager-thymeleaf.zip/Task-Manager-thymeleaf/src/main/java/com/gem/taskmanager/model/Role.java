package com.gem.taskmanager.model;

//JPA - this things give you ADNOTATIONS, HIBERNATE
public enum Role {
    USER,
    ADMIN
}
