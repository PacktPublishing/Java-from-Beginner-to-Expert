package arrays;

public class Arrays {

  
    public static void main(String[] args) {

           /*
                ARRAY
        
                ARRAYS HAVE TO BE COUNTED FROM 0 !!!!!!!!!!!!!!!!!!!
            
            */
        
        int[] array = new int[3]; // int - 32 bit * 3     
        
       
        
        array[0] = 70;
        array[1] = 40;
        array[2] = 440;
        
        
        System.out.println(array[0]);
        System.out.println(array[1]);
        System.out.println(array[2]);
        
        
        int[] array2 = {124, 14, 124, 512, 55, 512, 555};
        
        System.out.println(array2[array2.length - 1]);
    }
    
}
