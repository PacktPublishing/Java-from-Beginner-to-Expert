package relationaloperators;

public class Relationaloperators {

    public static void main(String[] args) {
        /*
            Relational operators (comparison operators)
            
            == - it compares two variables and checks if variables are equal
            != - checks if two variables are not equal to each other
            > - greater than
            >= - greater than or equal to
            < - less than
            <= - less than or equal
        */
        
        int a = 5,
            b = 5;
        
       
        
        boolean isTrue = false;
        System.out.println(isTrue);
        
        if (a > b)
            System.out.println("test");
    }
    
}
