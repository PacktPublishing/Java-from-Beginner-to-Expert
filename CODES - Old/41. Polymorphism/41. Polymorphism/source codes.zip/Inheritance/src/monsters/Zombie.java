
package monsters;


public class Zombie extends Monster
{
    
}
