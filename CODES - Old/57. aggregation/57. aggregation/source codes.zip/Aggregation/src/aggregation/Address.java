
package aggregation;

class Address 
{
    String streetName;
    int streetNumber;
    String country;

    public Address(String streetName, int streetNumber, String country) {
        this.streetName = streetName;
        this.streetNumber = streetNumber;
        this.country = country;
    }
    
    
}
