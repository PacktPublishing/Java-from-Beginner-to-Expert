
package references;

public class References {

    public static void main(String[] args) {
        String name = "Arkadiusz"; //literal
        String name2 = "Arkadiusz";
        
        if (name.equals(name2))
            System.out.println("They are equal");
        else
            System.out.println("They are not equal");
    }
    
}
