package inheritance;

import monsters.Monster;
import monsters.Skeleton;
import monsters.Zombie;

public class Inheritance {

    public static void main(String[] args) {
        Monster m = new Skeleton();
        
        
        
        
    }
    static void whatever(Monster monster)
    {
        
    }
    
}
