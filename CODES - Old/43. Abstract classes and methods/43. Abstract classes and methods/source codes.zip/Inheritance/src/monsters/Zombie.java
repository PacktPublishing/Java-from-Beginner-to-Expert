
package monsters;


public class Zombie extends Monster
{

    @Override
    protected void description() {
        
    }
    
}
